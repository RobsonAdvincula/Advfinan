import { useState, useMemo } from 'react';
import { Income, Expense, MonthlyReport, PersonReport } from '../types';
import { FAMILY_MEMBERS } from '../data/familyMembers';
import { useLocalStorage } from './useLocalStorage';
import { getCurrentMonth, getDaysInCurrentMonth, getCurrentDayOfMonth } from '../utils/dateUtils';

export const useFinancialData = () => {
  const [incomes, setIncomes] = useLocalStorage<Income[]>('family-incomes', []);
  const [expenses, setExpenses] = useLocalStorage<Expense[]>('family-expenses', []);

  const currentMonth = getCurrentMonth();

  // Filtrar dados do mês atual
  const currentMonthIncomes = useMemo(() => 
    incomes.filter(income => income.date.startsWith(currentMonth)),
    [incomes, currentMonth]
  );

  const currentMonthExpenses = useMemo(() =>
    expenses.filter(expense => expense.date.startsWith(currentMonth)),
    [expenses, currentMonth]
  );

  // Calcular relatório geral
  const generalReport: MonthlyReport = useMemo(() => {
    const totalIncome = currentMonthIncomes.reduce((sum, income) => sum + income.amount, 0);
    const totalExpenses = currentMonthExpenses.reduce((sum, expense) => sum + expense.amount, 0);
    const balance = totalIncome - totalExpenses;
    const dailyAverage = totalExpenses / getCurrentDayOfMonth();

    // Top 5 categorias
    const categoryTotals = currentMonthExpenses.reduce((acc, expense) => {
      acc[expense.category] = (acc[expense.category] || 0) + expense.amount;
      return acc;
    }, {} as Record<string, number>);

    const topCategories = Object.entries(categoryTotals)
      .sort(([, a], [, b]) => b - a)
      .slice(0, 5)
      .map(([category, amount]) => ({
        category: category as any,
        amount,
        percentage: totalExpenses > 0 ? (amount / totalExpenses) * 100 : 0
      }));

    return {
      totalIncome,
      totalExpenses,
      balance,
      dailyAverage,
      topCategories
    };
  }, [currentMonthIncomes, currentMonthExpenses]);

  // Calcular relatórios por pessoa
  const personReports: PersonReport[] = useMemo(() => {
    return FAMILY_MEMBERS.map(member => {
      const memberIncomes = currentMonthIncomes.filter(income => income.responsibleId === member.id);
      const memberExpenses = currentMonthExpenses.filter(expense => expense.responsibleId === member.id);

      const totalIncome = memberIncomes.reduce((sum, income) => sum + income.amount, 0);
      const totalExpenses = memberExpenses.reduce((sum, expense) => sum + expense.amount, 0);
      const balance = totalIncome - totalExpenses;
      const dailyAverage = totalExpenses / getCurrentDayOfMonth();

      // Top 5 categorias da pessoa
      const categoryTotals = memberExpenses.reduce((acc, expense) => {
        acc[expense.category] = (acc[expense.category] || 0) + expense.amount;
        return acc;
      }, {} as Record<string, number>);

      const topCategories = Object.entries(categoryTotals)
        .sort(([, a], [, b]) => b - a)
        .slice(0, 5)
        .map(([category, amount]) => ({
          category: category as any,
          amount,
          percentage: totalExpenses > 0 ? (amount / totalExpenses) * 100 : 0
        }));

      return {
        personId: member.id,
        personName: member.name,
        totalIncome,
        totalExpenses,
        balance,
        dailyAverage,
        topCategories
      };
    });
  }, [currentMonthIncomes, currentMonthExpenses]);

  // Funções para adicionar dados
  const addIncome = (incomeData: Omit<Income, 'id' | 'createdAt'>) => {
    const newIncome: Income = {
      ...incomeData,
      id: Date.now().toString(),
      createdAt: new Date().toISOString()
    };
    setIncomes(prev => [...prev, newIncome]);
  };

  const addExpense = (expenseData: Omit<Expense, 'id' | 'createdAt'>) => {
    const newExpense: Expense = {
      ...expenseData,
      id: Date.now().toString(),
      createdAt: new Date().toISOString()
    };
    setExpenses(prev => [...prev, newExpense]);
  };

  // Funções para deletar dados
  const deleteIncome = (id: string) => {
    setIncomes(prev => prev.filter(income => income.id !== id));
  };

  const deleteExpense = (id: string) => {
    setExpenses(prev => prev.filter(expense => expense.id !== id));
  };

  return {
    // Dados
    incomes: currentMonthIncomes,
    expenses: currentMonthExpenses,
    generalReport,
    personReports,
    
    // Ações
    addIncome,
    addExpense,
    deleteIncome,
    deleteExpense
  };
};