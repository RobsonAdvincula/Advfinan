import React from 'react';
import { TrendingUp, TrendingDown, DollarSign, Calendar } from 'lucide-react';
import { formatCurrency } from '../utils/dateUtils';
import { MonthlyReport } from '../types';

interface DashboardProps {
  report: MonthlyReport;
}

export const Dashboard: React.FC<DashboardProps> = ({ report }) => {
  const { totalIncome, totalExpenses, balance, dailyAverage } = report;

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
      <div className="bg-white rounded-lg p-6 shadow-md border-l-4 border-green-500">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-gray-600">Ganhos do Mês</p>
            <p className="text-2xl font-bold text-green-600">{formatCurrency(totalIncome)}</p>
          </div>
          <TrendingUp className="h-8 w-8 text-green-500" />
        </div>
      </div>

      <div className="bg-white rounded-lg p-6 shadow-md border-l-4 border-red-500">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-gray-600">Gastos do Mês</p>
            <p className="text-2xl font-bold text-red-600">{formatCurrency(totalExpenses)}</p>
          </div>
          <TrendingDown className="h-8 w-8 text-red-500" />
        </div>
      </div>

      <div className={`bg-white rounded-lg p-6 shadow-md border-l-4 ${balance >= 0 ? 'border-blue-500' : 'border-red-500'}`}>
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-gray-600">Saldo Atual</p>
            <p className={`text-2xl font-bold ${balance >= 0 ? 'text-blue-600' : 'text-red-600'}`}>
              {formatCurrency(balance)}
            </p>
          </div>
          <DollarSign className={`h-8 w-8 ${balance >= 0 ? 'text-blue-500' : 'text-red-500'}`} />
        </div>
      </div>

      <div className="bg-white rounded-lg p-6 shadow-md border-l-4 border-purple-500">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-gray-600">Média Diária</p>
            <p className="text-2xl font-bold text-purple-600">{formatCurrency(dailyAverage)}</p>
          </div>
          <Calendar className="h-8 w-8 text-purple-500" />
        </div>
      </div>
    </div>
  );
};