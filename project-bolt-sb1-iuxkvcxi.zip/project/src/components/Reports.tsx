import React, { useState } from 'react';
import { BarChart, PieChart, User, Users } from 'lucide-react';
import { MonthlyReport, PersonReport } from '../types';
import { FAMILY_MEMBERS } from '../data/familyMembers';
import { formatCurrency } from '../utils/dateUtils';

interface ReportsProps {
  generalReport: MonthlyReport;
  personReports: PersonReport[];
}

export const Reports: React.FC<ReportsProps> = ({ generalReport, personReports }) => {
  const [selectedPerson, setSelectedPerson] = useState<string>('general');

  const currentReport = selectedPerson === 'general' 
    ? generalReport 
    : personReports.find(r => r.personId === selectedPerson) || generalReport;

  const isPersonReport = selectedPerson !== 'general';

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-lg p-6 shadow-md">
        <h2 className="text-xl font-semibold text-gray-800 mb-4 flex items-center gap-2">
          <BarChart className="h-5 w-5" />
          Relatórios Mensais
        </h2>
        
        <div className="mb-6">
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Filtrar por pessoa:
          </label>
          <select
            value={selectedPerson}
            onChange={(e) => setSelectedPerson(e.target.value)}
            className="px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          >
            <option value="general">📊 Relatório Geral</option>
            {FAMILY_MEMBERS.map(member => (
              <option key={member.id} value={member.id}>
                👤 {member.name}
              </option>
            ))}
          </select>
        </div>

        {/* Métricas Principais */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          <div className="bg-gradient-to-r from-green-50 to-green-100 rounded-lg p-4 border border-green-200">
            <div className="flex items-center gap-2 mb-2">
              <div className="p-1 bg-green-200 rounded">
                <Users className="h-4 w-4 text-green-700" />
              </div>
              <h3 className="font-medium text-green-800">
                {isPersonReport ? 'Ganhos Pessoais' : 'Ganhos Totais'}
              </h3>
            </div>
            <p className="text-2xl font-bold text-green-700">
              {formatCurrency(currentReport.totalIncome)}
            </p>
          </div>

          <div className="bg-gradient-to-r from-red-50 to-red-100 rounded-lg p-4 border border-red-200">
            <div className="flex items-center gap-2 mb-2">
              <div className="p-1 bg-red-200 rounded">
                <User className="h-4 w-4 text-red-700" />
              </div>
              <h3 className="font-medium text-red-800">
                {isPersonReport ? 'Gastos Pessoais' : 'Gastos Totais'}
              </h3>
            </div>
            <p className="text-2xl font-bold text-red-700">
              {formatCurrency(currentReport.totalExpenses)}
            </p>
          </div>

          <div className={`bg-gradient-to-r rounded-lg p-4 border ${
            currentReport.balance >= 0 
              ? 'from-blue-50 to-blue-100 border-blue-200' 
              : 'from-orange-50 to-orange-100 border-orange-200'
          }`}>
            <div className="flex items-center gap-2 mb-2">
              <div className={`p-1 rounded ${
                currentReport.balance >= 0 ? 'bg-blue-200' : 'bg-orange-200'
              }`}>
                <BarChart className={`h-4 w-4 ${
                  currentReport.balance >= 0 ? 'text-blue-700' : 'text-orange-700'
                }`} />
              </div>
              <h3 className={`font-medium ${
                currentReport.balance >= 0 ? 'text-blue-800' : 'text-orange-800'
              }`}>
                Saldo
              </h3>
            </div>
            <p className={`text-2xl font-bold ${
              currentReport.balance >= 0 ? 'text-blue-700' : 'text-orange-700'
            }`}>
              {formatCurrency(currentReport.balance)}
            </p>
          </div>

          <div className="bg-gradient-to-r from-purple-50 to-purple-100 rounded-lg p-4 border border-purple-200">
            <div className="flex items-center gap-2 mb-2">
              <div className="p-1 bg-purple-200 rounded">
                <PieChart className="h-4 w-4 text-purple-700" />
              </div>
              <h3 className="font-medium text-purple-800">Média Diária</h3>
            </div>
            <p className="text-2xl font-bold text-purple-700">
              {formatCurrency(currentReport.dailyAverage)}
            </p>
          </div>
        </div>

        {/* Top 5 Categorias */}
        <div className="bg-gray-50 rounded-lg p-4">
          <h3 className="font-semibold text-gray-800 mb-4 flex items-center gap-2">
            <PieChart className="h-4 w-4" />
            Top 5 Categorias de Gastos
          </h3>
          
          {currentReport.topCategories.length === 0 ? (
            <p className="text-gray-500 text-center py-4">
              Nenhuma despesa registrada no período
            </p>
          ) : (
            <div className="space-y-3">
              {currentReport.topCategories.map((category, index) => (
                <div key={category.category} className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className={`flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center text-white font-bold text-sm ${
                      index === 0 ? 'bg-red-500' :
                      index === 1 ? 'bg-orange-500' :
                      index === 2 ? 'bg-yellow-500' :
                      index === 3 ? 'bg-green-500' :
                      'bg-blue-500'
                    }`}>
                      {index + 1}
                    </div>
                    <div>
                      <p className="font-medium text-gray-800">{category.category}</p>
                      <p className="text-sm text-gray-500">{category.percentage.toFixed(1)}% do total</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-bold text-gray-800">{formatCurrency(category.amount)}</p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Resumo por Pessoa (apenas no relatório geral) */}
        {selectedPerson === 'general' && personReports.length > 0 && (
          <div className="mt-6 bg-blue-50 rounded-lg p-4">
            <h3 className="font-semibold text-blue-800 mb-4 flex items-center gap-2">
              <Users className="h-4 w-4" />
              Resumo por Membro da Família
            </h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {personReports.map(report => (
                <div key={report.personId} className="bg-white rounded-lg p-4 border border-blue-200">
                  <h4 className="font-medium text-blue-800 mb-2">{report.personName}</h4>
                  <div className="space-y-1 text-sm">
                    <div className="flex justify-between">
                      <span className="text-gray-600">Ganhos:</span>
                      <span className="font-medium text-green-600">{formatCurrency(report.totalIncome)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Gastos:</span>
                      <span className="font-medium text-red-600">{formatCurrency(report.totalExpenses)}</span>
                    </div>
                    <div className="flex justify-between border-t pt-1">
                      <span className="text-gray-600">Saldo:</span>
                      <span className={`font-bold ${report.balance >= 0 ? 'text-blue-600' : 'text-red-600'}`}>
                        {formatCurrency(report.balance)}
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};