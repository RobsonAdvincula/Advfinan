import React, { useState } from 'react';
import { Plus } from 'lucide-react';
import { Income } from '../types';
import { FAMILY_MEMBERS } from '../data/familyMembers';
import { getCurrentMonth } from '../utils/dateUtils';

interface IncomeFormProps {
  onAddIncome: (income: Omit<Income, 'id' | 'createdAt'>) => void;
}

export const IncomeForm: React.FC<IncomeFormProps> = ({ onAddIncome }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [formData, setFormData] = useState({
    date: getCurrentMonth(),
    amount: '',
    description: '',
    responsibleId: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.amount || !formData.description || !formData.responsibleId) {
      alert('Preencha todos os campos obrigatórios');
      return;
    }

    onAddIncome({
      date: formData.date,
      amount: parseFloat(formData.amount),
      description: formData.description,
      responsibleId: formData.responsibleId
    });

    setFormData({
      date: getCurrentMonth(),
      amount: '',
      description: '',
      responsibleId: ''
    });
    setIsOpen(false);
  };

  const earningMembers = FAMILY_MEMBERS.filter(member => member.canEarn);

  if (!isOpen) {
    return (
      <button
        onClick={() => setIsOpen(true)}
        className="bg-green-500 hover:bg-green-600 text-white px-4 py-2 rounded-lg flex items-center gap-2 transition-colors"
      >
        <Plus className="h-4 w-4" />
        Adicionar Ganho
      </button>
    );
  }

  return (
    <div className="bg-white rounded-lg p-6 shadow-md">
      <h3 className="text-lg font-semibold text-gray-800 mb-4">Registrar Ganho</h3>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Mês/Ano *
            </label>
            <input
              type="month"
              value={formData.date}
              onChange={(e) => setFormData({ ...formData, date: e.target.value })}
              className="w-full p-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-green-500 focus:border-transparent"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Valor (R$) *
            </label>
            <input
              type="number"
              step="0.01"
              min="0"
              value={formData.amount}
              onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
              className="w-full p-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-green-500 focus:border-transparent"
              placeholder="0,00"
              required
            />
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Descrição *
          </label>
          <input
            type="text"
            value={formData.description}
            onChange={(e) => setFormData({ ...formData, description: e.target.value })}
            className="w-full p-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-green-500 focus:border-transparent"
            placeholder="Ex: Salário Principal, Renda Extra"
            required
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Responsável *
          </label>
          <select
            value={formData.responsibleId}
            onChange={(e) => setFormData({ ...formData, responsibleId: e.target.value })}
            className="w-full p-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-green-500 focus:border-transparent"
            required
          >
            <option value="">Selecione o responsável</option>
            {earningMembers.map(member => (
              <option key={member.id} value={member.id}>
                {member.name}
              </option>
            ))}
          </select>
        </div>

        <div className="flex gap-2 pt-4">
          <button
            type="submit"
            className="bg-green-500 hover:bg-green-600 text-white px-4 py-2 rounded-md transition-colors flex-1"
          >
            Salvar Ganho
          </button>
          <button
            type="button"
            onClick={() => setIsOpen(false)}
            className="bg-gray-300 hover:bg-gray-400 text-gray-700 px-4 py-2 rounded-md transition-colors"
          >
            Cancelar
          </button>
        </div>
      </form>
    </div>
  );
};