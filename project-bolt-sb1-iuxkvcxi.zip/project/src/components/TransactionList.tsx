import React, { useState } from 'react';
import { Trash2, Search, TrendingUp, TrendingDown } from 'lucide-react';
import { Income, Expense } from '../types';
import { FAMILY_MEMBERS } from '../data/familyMembers';
import { formatCurrency, formatDate } from '../utils/dateUtils';

interface TransactionListProps {
  incomes: Income[];
  expenses: Expense[];
  onDeleteIncome: (id: string) => void;
  onDeleteExpense: (id: string) => void;
}

export const TransactionList: React.FC<TransactionListProps> = ({
  incomes,
  expenses,
  onDeleteIncome,
  onDeleteExpense
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState<'all' | 'income' | 'expense'>('all');

  const getFamilyMemberName = (id: string) => {
    return FAMILY_MEMBERS.find(member => member.id === id)?.name || 'Desconhecido';
  };

  // Combinar transações e ordenar por data
  const allTransactions = [
    ...incomes.map(income => ({ ...income, type: 'income' as const })),
    ...expenses.map(expense => ({ ...expense, type: 'expense' as const }))
  ].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

  // Filtrar transações
  const filteredTransactions = allTransactions.filter(transaction => {
    const matchesSearch = transaction.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         getFamilyMemberName(transaction.responsibleId).toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesFilter = filterType === 'all' || 
                         (filterType === 'income' && transaction.type === 'income') ||
                         (filterType === 'expense' && transaction.type === 'expense');
    
    return matchesSearch && matchesFilter;
  });

  const handleDelete = (transaction: typeof allTransactions[0]) => {
    if (window.confirm(`Tem certeza que deseja excluir "${transaction.description}"?`)) {
      if (transaction.type === 'income') {
        onDeleteIncome(transaction.id);
      } else {
        onDeleteExpense(transaction.id);
      }
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden">
      <div className="p-6 border-b border-gray-200">
        <h2 className="text-xl font-semibold text-gray-800 mb-4">Transações do Mês</h2>
        
        <div className="flex flex-col sm:flex-row gap-4">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
            <input
              type="text"
              placeholder="Pesquisar transações..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
          
          <select
            value={filterType}
            onChange={(e) => setFilterType(e.target.value as 'all' | 'income' | 'expense')}
            className="px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          >
            <option value="all">Todas</option>
            <option value="income">Ganhos</option>
            <option value="expense">Despesas</option>
          </select>
        </div>
      </div>

      <div className="max-h-96 overflow-y-auto">
        {filteredTransactions.length === 0 ? (
          <div className="p-8 text-center text-gray-500">
            <p>Nenhuma transação encontrada</p>
          </div>
        ) : (
          <div className="divide-y divide-gray-100">
            {filteredTransactions.map((transaction) => (
              <div key={`${transaction.type}-${transaction.id}`} className="p-4 hover:bg-gray-50 transition-colors">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3 flex-1">
                    <div className={`p-2 rounded-full ${
                      transaction.type === 'income' 
                        ? 'bg-green-100 text-green-600' 
                        : 'bg-red-100 text-red-600'
                    }`}>
                      {transaction.type === 'income' ? (
                        <TrendingUp className="h-4 w-4" />
                      ) : (
                        <TrendingDown className="h-4 w-4" />
                      )}
                    </div>
                    
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <p className="font-medium text-gray-900 truncate">
                          {transaction.description}
                        </p>
                        {transaction.type === 'expense' && (
                          <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                            {(transaction as Expense).category}
                          </span>
                        )}
                      </div>
                      <p className="text-sm text-gray-500">
                        {getFamilyMemberName(transaction.responsibleId)} • {formatDate(transaction.date)}
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-2">
                    <span className={`font-bold text-lg ${
                      transaction.type === 'income' ? 'text-green-600' : 'text-red-600'
                    }`}>
                      {transaction.type === 'income' ? '+' : '-'}{formatCurrency(transaction.amount)}
                    </span>
                    
                    <button
                      onClick={() => handleDelete(transaction)}
                      className="p-2 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded-full transition-colors"
                      title="Excluir transação"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};