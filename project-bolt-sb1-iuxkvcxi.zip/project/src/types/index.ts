export interface FamilyMember {
  id: string;
  name: string;
  canEarn: boolean; // Apenas pais podem ter ganhos
}

export interface Income {
  id: string;
  date: string; // YYYY-MM format for monthly income
  amount: number;
  description: string;
  responsibleId: string;
  createdAt: string;
}

export interface Expense {
  id: string;
  date: string; // YYYY-MM-DD format for daily expenses
  amount: number;
  description: string;
  category: ExpenseCategory;
  responsibleId: string;
  createdAt: string;
}

export type ExpenseCategory = 
  | 'Alimentação'
  | 'Moradia'
  | 'Transporte'
  | 'Lazer'
  | 'Educação'
  | 'Saúde'
  | 'Outros';

export interface MonthlyReport {
  totalIncome: number;
  totalExpenses: number;
  balance: number;
  dailyAverage: number;
  topCategories: Array<{
    category: ExpenseCategory;
    amount: number;
    percentage: number;
  }>;
}

export interface PersonReport extends MonthlyReport {
  personId: string;
  personName: string;
}