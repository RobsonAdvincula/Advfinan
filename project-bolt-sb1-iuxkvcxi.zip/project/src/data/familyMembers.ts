import { FamilyMember } from '../types';

export const FAMILY_MEMBERS: FamilyMember[] = [
  { id: '1', name: 'João Advincula', canEarn: true },
  { id: '2', name: 'Maria Advincula', canEarn: true },
  { id: '3', name: 'Pedro Advincula', canEarn: false },
  { id: '4', name: 'Ana Advincula', canEarn: false }
];

export const EXPENSE_CATEGORIES = [
  'Alimentação',
  'Moradia',
  'Transporte',
  'Lazer',
  'Educação',
  'Saúde',
  'Outros'
] as const;