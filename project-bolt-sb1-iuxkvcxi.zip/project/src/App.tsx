import React, { useState } from 'react';
import { PiggyBank, BarChart3, List, Home } from 'lucide-react';
import { Dashboard } from './components/Dashboard';
import { IncomeForm } from './components/IncomeForm';
import { ExpenseForm } from './components/ExpenseForm';
import { TransactionList } from './components/TransactionList';
import { Reports } from './components/Reports';
import { useFinancialData } from './hooks/useFinancialData';

type TabType = 'dashboard' | 'transactions' | 'reports';

function App() {
  const [activeTab, setActiveTab] = useState<TabType>('dashboard');
  const {
    incomes,
    expenses,
    generalReport,
    personReports,
    addIncome,
    addExpense,
    deleteIncome,
    deleteExpense
  } = useFinancialData();

  const tabs = [
    { id: 'dashboard' as const, name: 'Dashboard', icon: Home },
    { id: 'transactions' as const, name: 'Transações', icon: List },
    { id: 'reports' as const, name: 'Relatórios', icon: BarChart3 }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-blue-600 rounded-lg">
                <PiggyBank className="h-6 w-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-gray-900">
                  Gestão Financeira
                </h1>
                <p className="text-sm text-gray-500">Família Advincula</p>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Navigation Tabs */}
      <nav className="bg-white border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex space-x-8">
            {tabs.map((tab) => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`flex items-center gap-2 py-4 px-1 border-b-2 font-medium text-sm transition-colors ${
                    activeTab === tab.id
                      ? 'border-blue-500 text-blue-600'
                      : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                  }`}
                >
                  <Icon className="h-4 w-4" />
                  {tab.name}
                </button>
              );
            })}
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {activeTab === 'dashboard' && (
          <div className="space-y-6">
            <Dashboard report={generalReport} />
            
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <IncomeForm onAddIncome={addIncome} />
              <ExpenseForm onAddExpense={addExpense} />
            </div>
          </div>
        )}

        {activeTab === 'transactions' && (
          <TransactionList
            incomes={incomes}
            expenses={expenses}
            onDeleteIncome={deleteIncome}
            onDeleteExpense={deleteExpense}
          />
        )}

        {activeTab === 'reports' && (
          <Reports
            generalReport={generalReport}
            personReports={personReports}
          />
        )}
      </main>

      {/* Footer */}
      <footer className="bg-white border-t mt-auto">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <p className="text-center text-sm text-gray-500">
            © 2024 Gestão Financeira Família Advincula. Todos os direitos reservados.
          </p>
        </div>
      </footer>
    </div>
  );
}

export default App;